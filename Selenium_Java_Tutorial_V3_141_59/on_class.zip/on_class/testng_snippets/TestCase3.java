package testng_snippets;

import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TestCase3 {
  @Test
  public void f() {
	  List <Integer> a=new ArrayList<Integer>();
	  a.add(1);
	  a.add(15);
	  a.add(61);
	  a.add(23);
	  for (int x : a)
	  {
		  System.out.println(x);
		  Assert.assertTrue(x<50);
	  }
  }
}
