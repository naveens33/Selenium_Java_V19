package testng_snippets;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;

public class TestCase2 {
	
  @Parameters({"username","password"})
	@Test
  public void f(@Optional("Naveen.S")String u ,@Optional("Somethign123")String p) {
	  System.out.println(u+" "+p);
  }
  
  @Parameters({"username","password"})
  @BeforeMethod
  public void beforeMethod(@Optional("Naveen.S")String u ,@Optional("Somethign123")String p) {
	  System.out.println("********BeforeMethod*********** "+u+" "+p);
  }

  @Parameters({"username","password"})
  @BeforeClass
  public void beforeClass(@Optional("Naveen.S")String u ,@Optional("Somethign123")String p) {
	  System.out.println("********BeforeClass*********** "+u+" "+p);
  }

  @Parameters({"browser","url"})
  @BeforeSuite
  public void beforeSuite(@Optional("firfox")String u ,@Optional("www.something.com")String p)
  {
	  System.out.println("********BeforeSuite*********** "+u+" "+p);
  }
  @AfterSuite
  public void afterSuite()
  {
	  System.out.println("********AfterSuite");
  }
}
