package testng_snippets;

import org.testng.annotations.Test;

import org.testng.Assert;
import org.testng.annotations.DataProvider;

public class TestCase4 {
  @Test(dataProvider = "dp")
  public void f(Integer n) {
	  Assert.assertTrue(n<50);
  }

  @DataProvider
  public Object[] dp() {
    return new Object[]{1,15,61,23};
    }
}
