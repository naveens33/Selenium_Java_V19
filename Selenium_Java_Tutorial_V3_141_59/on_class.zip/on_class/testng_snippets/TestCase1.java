package testng_snippets;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeGroups;

public class TestCase1 {
  @Test
  public void test01() {
	  System.out.println("****test01");
  }
  
  @Test
  public void test02() {
	  System.out.println("****test02");
  }
 
  @Test(groups="important")
  public void test03() {
	  System.out.println("****test03");
  }

  @Test(groups="important")
  public void test04() {
	  System.out.println("****test04");
  }

  @Test(enabled=false)
  public void test05() {
	  System.out.println("****test05");
  }
  
  @Test(expectedExceptions = ArithmeticException.class)
  public void test06() {
	  System.out.println("****test06");
	  throw(new ArithmeticException());
  }

  @Test(timeOut = 1000)
  public void test07() throws InterruptedException {
	  System.out.println("****test07");
	  //Thread.sleep(1001);
  }
  
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("***beforeMethod");
  }

  @AfterMethod
  public void afterMethod() {
	  System.out.println("***afterMethod");
  }

  @BeforeClass
  public void beforeClass()
  {
	  System.out.println("*beforeClass");  
  }
  
  @AfterClass
  public void afterClass()
  {
	  System.out.println("*afterClass");  
  }
  
  @BeforeGroups("important")
  public void beforeGroups()
  {
	  System.out.println("**beforeGroups");  
  }
  
  @AfterGroups("important")
  public void afterGroups()
  {
	  System.out.println("**afterGroups");  
  }
  
  @BeforeTest
  public void beforeTest()
  {
	  System.out.println("beforeTest");  
  }
  
  @AfterTest
  public void afterTest()
  {
	  System.out.println("afterTest");  
  }
  
}
