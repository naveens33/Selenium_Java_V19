package testng_examples;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

public class AddNewPayee {
	WebDriver driver;  
	@BeforeClass
	  public void beforeClass() {
		  System.setProperty("webdriver.chrome.driver", "D:\\Naveen\\Selenium\\chromedriver_win32\\chromedriver.exe");
			
			driver=new ChromeDriver();
			driver.manage().window().maximize();
			
			driver.navigate().to("http://zero.webappsecurity.com/");
			WebElement signin1=driver.findElement(By.id("signin_button"));
			signin1.click();
			
			driver.findElement(By.id("user_login")).sendKeys("username");
			driver.findElement(By.id("user_password")).sendKeys("password");
			driver.findElement(By.name("submit")).click();
			
			driver.findElement(By.xpath("//a[text()='Pay Bills']")).click();

	  }
	  
	@BeforeMethod
	public void beforeMethod()
	{
		driver.findElement(By.xpath("//a[text()='Add New Payee']")).click();
	}
	
	@Test(dataProvider="dp")
    public void f(String name,String addr,String acc,String details) {
		WebDriverWait wait=new WebDriverWait(driver, 5);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("np_new_payee_name"))).sendKeys(name);
		driver.findElement(By.id("np_new_payee_address")).sendKeys(addr);
		driver.findElement(By.id("np_new_payee_account")).sendKeys(acc);
		driver.findElement(By.id("np_new_payee_details")).sendKeys(details);
		driver.findElement(By.id("add_new_payee")).click();
		String msg=driver.findElement(By.id("alert_content")).getText();
		Assert.assertTrue(msg.contains(name), "Confirmation message is not coming");
		//Assert.assertEquals(msg,"The new payee Prem was successfully created.","Confirmation message is not coming");
	}

	@DataProvider
	public Object[][] dp()
	{
		return new Object[][] {
			new Object[] {"Prem","Bangalore","312432343","Relation"},
			new Object[] {"Somi","Chennai","4623786782","Friend"},
			new Object[] {"Anish","Delhi","9788463574","Friend"}
		};
	}
	
}
