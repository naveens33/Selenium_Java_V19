package testng_examples;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelData {

	public static void main(String[] args) throws IOException {
		FileInputStream file =new FileInputStream("C:\\Users\\naveen.s\\git\\Selenium_Java_V19\\Selenium_Java_Tutorial_V3_141_59\\on_class\\testng_examples\\PayeeDetails.xlsx");
		XSSFWorkbook wb=new XSSFWorkbook(file);
		XSSFSheet sheet=wb.getSheet("PayeeDetails");
		
		System.out.println(sheet.getLastRowNum());
		
	}

}
